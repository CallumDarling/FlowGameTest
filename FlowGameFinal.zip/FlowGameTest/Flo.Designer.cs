﻿namespace FlowGameTest
{
    partial class Flo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dialogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EasyRadioButton = new System.Windows.Forms.RadioButton();
            this.MedRadioButton = new System.Windows.Forms.RadioButton();
            this.HardRadioButton = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.LevelButton1 = new System.Windows.Forms.Button();
            this.LevelButton2 = new System.Windows.Forms.Button();
            this.LevelButton3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.LblTimer = new System.Windows.Forms.Label();
            this.LblTimeNo = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.dialogToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(534, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.startToolStripMenuItem.Text = "How To Play";
            this.startToolStripMenuItem.Click += new System.EventHandler(this.startToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.helpToolStripMenuItem.Text = "High Score";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // dialogToolStripMenuItem
            // 
            this.dialogToolStripMenuItem.Name = "dialogToolStripMenuItem";
            this.dialogToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.dialogToolStripMenuItem.Text = "Exit";
            this.dialogToolStripMenuItem.Click += new System.EventHandler(this.dialogToolStripMenuItem_Click);
            // 
            // EasyRadioButton
            // 
            this.EasyRadioButton.AutoSize = true;
            this.EasyRadioButton.Location = new System.Drawing.Point(468, 33);
            this.EasyRadioButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.EasyRadioButton.Name = "EasyRadioButton";
            this.EasyRadioButton.Size = new System.Drawing.Size(48, 17);
            this.EasyRadioButton.TabIndex = 3;
            this.EasyRadioButton.TabStop = true;
            this.EasyRadioButton.Text = "Easy";
            this.EasyRadioButton.UseVisualStyleBackColor = true;
            this.EasyRadioButton.CheckedChanged += new System.EventHandler(this.EasyRadioButton_CheckedChanged);
            // 
            // MedRadioButton
            // 
            this.MedRadioButton.AutoSize = true;
            this.MedRadioButton.Location = new System.Drawing.Point(468, 55);
            this.MedRadioButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MedRadioButton.Name = "MedRadioButton";
            this.MedRadioButton.Size = new System.Drawing.Size(62, 17);
            this.MedRadioButton.TabIndex = 4;
            this.MedRadioButton.TabStop = true;
            this.MedRadioButton.Text = "Medium";
            this.MedRadioButton.UseVisualStyleBackColor = true;
            this.MedRadioButton.CheckedChanged += new System.EventHandler(this.MedRadioButton_CheckedChanged_1);
            // 
            // HardRadioButton
            // 
            this.HardRadioButton.AutoSize = true;
            this.HardRadioButton.Location = new System.Drawing.Point(468, 77);
            this.HardRadioButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.HardRadioButton.Name = "HardRadioButton";
            this.HardRadioButton.Size = new System.Drawing.Size(48, 17);
            this.HardRadioButton.TabIndex = 5;
            this.HardRadioButton.TabStop = true;
            this.HardRadioButton.Text = "Hard";
            this.HardRadioButton.UseVisualStyleBackColor = true;
            this.HardRadioButton.CheckedChanged += new System.EventHandler(this.HardRadioButton_CheckedChanged_1);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(468, 120);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(60, 20);
            this.textBox2.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(467, 144);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(59, 34);
            this.button2.TabIndex = 7;
            this.button2.Text = "Submit Solution";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // LevelButton1
            // 
            this.LevelButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.LevelButton1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LevelButton1.Location = new System.Drawing.Point(467, 98);
            this.LevelButton1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LevelButton1.Name = "LevelButton1";
            this.LevelButton1.Size = new System.Drawing.Size(15, 16);
            this.LevelButton1.TabIndex = 10;
            this.LevelButton1.Text = "1";
            this.LevelButton1.UseVisualStyleBackColor = true;
            this.LevelButton1.Click += new System.EventHandler(this.LevelButton1_Click);
            // 
            // LevelButton2
            // 
            this.LevelButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.LevelButton2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LevelButton2.Location = new System.Drawing.Point(489, 98);
            this.LevelButton2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LevelButton2.Name = "LevelButton2";
            this.LevelButton2.Size = new System.Drawing.Size(15, 16);
            this.LevelButton2.TabIndex = 11;
            this.LevelButton2.Text = "2";
            this.LevelButton2.UseVisualStyleBackColor = true;
            this.LevelButton2.Click += new System.EventHandler(this.LevelButton2_Click);
            // 
            // LevelButton3
            // 
            this.LevelButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.LevelButton3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LevelButton3.Location = new System.Drawing.Point(512, 98);
            this.LevelButton3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LevelButton3.Name = "LevelButton3";
            this.LevelButton3.Size = new System.Drawing.Size(15, 16);
            this.LevelButton3.TabIndex = 12;
            this.LevelButton3.Text = "3";
            this.LevelButton3.UseVisualStyleBackColor = true;
            this.LevelButton3.Click += new System.EventHandler(this.LevelButton3_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LblTimer
            // 
            this.LblTimer.AutoSize = true;
            this.LblTimer.Location = new System.Drawing.Point(465, 181);
            this.LblTimer.Name = "LblTimer";
            this.LblTimer.Size = new System.Drawing.Size(36, 13);
            this.LblTimer.TabIndex = 13;
            this.LblTimer.Text = "Time: ";
            this.LblTimer.Click += new System.EventHandler(this.label1_Click);
            // 
            // LblTimeNo
            // 
            this.LblTimeNo.AutoSize = true;
            this.LblTimeNo.Location = new System.Drawing.Point(501, 181);
            this.LblTimeNo.Name = "LblTimeNo";
            this.LblTimeNo.Size = new System.Drawing.Size(13, 13);
            this.LblTimeNo.TabIndex = 14;
            this.LblTimeNo.Text = "0";
            this.LblTimeNo.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Flo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(534, 411);
            this.Controls.Add(this.LblTimeNo);
            this.Controls.Add(this.LblTimer);
            this.Controls.Add(this.LevelButton3);
            this.Controls.Add(this.LevelButton2);
            this.Controls.Add(this.LevelButton1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.HardRadioButton);
            this.Controls.Add(this.MedRadioButton);
            this.Controls.Add(this.EasyRadioButton);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.Azure;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Flo";
            this.Text = "Flo";
            this.Load += new System.EventHandler(this.Flo_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dialogToolStripMenuItem;
        private System.Windows.Forms.RadioButton EasyRadioButton;
        private System.Windows.Forms.RadioButton MedRadioButton;
        private System.Windows.Forms.RadioButton HardRadioButton;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button LevelButton1;
        private System.Windows.Forms.Button LevelButton2;
        private System.Windows.Forms.Button LevelButton3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label LblTimer;
        private System.Windows.Forms.Label LblTimeNo;
    }
}

