﻿using FlowFreeNew;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlowGameTest
{
    public partial class Flo : Form
    {
        Random r = new Random();
        //declare  variables that will be needed later
        double time = 0;
        int diffOffset = 0;
        int currentLevel = 0;
        //this is the array of level solutions in string form, these will be compared when a user submits their attempt
        String[] solutions = { "9175180;9175180;9175180;9175180;9175180;:5111886;5111886;5111886;5111886;9175180;:10944679;2359332;2359332;2359332;8257662;:10944679;2359332;10944679;2359332;8257662;:10944679;10944679;10944679;2359332;8257662;:"
            , "5111886;10944679;10944679;10944679;8257662;:5111886;5111886;8257662;8257662;8257662;:9175180;5111886;8257662;2359332;2359332;:9175180;5111886;5111886;5111886;2359332;:9175180;9175180;9175180;9175180;2359332;:"
            , "8257662;8257662;8257662;8257662;8257662;:8257662;9175180;9175180;9175180;8257662;:10944679;2359332;2359332;2359332;2359332;:10944679;2359332;5111886;5111886;2359332;:10944679;5111886;5111886;2359332;2359332;:"
            , "9175180;9175180;9175180;9175180;9175180;9175180;:9175180;2359332;2359332;5111886;5111886;9175180;:10944679;10944679;2359332;2359332;5111886;9175180;:10944679;8257662;8257662;2359332;5111886;9175180;:10944679;10944679;8257662;2359332;5111886;2359332;:8257662;8257662;8257662;2359332;2359332;2359332;:"
            , "9175180;9175180;9175180;9175180;9175180;9175180;:8257662;8257662;8257662;8257662;2359332;9175180;:8257662;10944679;10944679;10944679;2359332;5111886;:8257662;10944679;5111886;5111886;2359332;5111886;:8257662;10944679;8257662;5111886;2359332;5111886;:8257662;8257662;8257662;5111886;5111886;5111886;:"
            , "8257662;8257662;8257662;8257662;8257662;8257662;:8257662;5111886;5111886;5111886;5111886;10944679;:8257662;9175180;9175180;9175180;5111886;10944679;:8257662;5111886;5111886;5111886;5111886;10944679;:8257662;5111886;2359332;2359332;2359332;10944679;:8257662;5111886;5111886;10944679;10944679;10944679;:"
            , "2359332;2359332;2359332;2359332;2359332;2359332;2359332;:2359332;8257662;8257662;8257662;8257662;8257662;9175180;:2359332;8257662;9175180;9175180;9175180;9175180;9175180;:2359332;9175180;9175180;5111886;8913032;8913032;8913032;:2359332;9175180;5111886;5111886;10944679;10944679;8913032;:2359332;9175180;9175180;9175180;9175180;10944679;8913032;:2359332;2359332;2359332;2359332;2359332;2359332;8913032;:"
            , "5111886;9175180;9175180;9175180;9175180;9175180;10944679;:5111886;10944679;10944679;10944679;10944679;9175180;10944679;:5111886;2359332;2359332;2359332;10944679;10944679;10944679;:5111886;8257662;8257662;2359332;2359332;2359332;2359332;:5111886;8913032;8257662;8257662;8257662;8257662;2359332;:5111886;8913032;8913032;8913032;8913032;8257662;2359332;:5111886;5111886;5111886;5111886;8913032;2359332;2359332;:"
            , "5111886;9175180;9175180;9175180;9175180;8913032;8913032;:5111886;9175180;8913032;8913032;8913032;8913032;8257662;:5111886;9175180;8913032;8257662;8257662;8257662;8257662;:5111886;9175180;8913032;8257662;10944679;10944679;10944679;:5111886;9175180;8913032;8913032;5111886;2359332;10944679;:5111886;9175180;9175180;9175180;5111886;2359332;10944679;:5111886;5111886;5111886;5111886;5111886;2359332;10944679;:"
        };      
  
        Button[,] btn = new Button[5, 5];       // Create 2D array of buttons
        //Button[] unkillable = new Button[25];
        List<Button> unkillable = new List<Button>();
        Boolean clickHeld = false;
        Color clickColor = Color.NavajoWhite;
        public Flo()
        {
            //sets windows size and makes it unresizable
            InitializeComponent();
            this.Size = new System.Drawing.Size(600, 450);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            //addButtons();
        }
        //removes clears button array
        public void killButtons() {
            unkillable.Clear();
            for (int x = 0; x < btn.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < btn.GetLength(1); y++)     // Loop for y
                {
                   this.Controls.Remove(btn[x, y]);
                }
            }

        }
        public void killColor()
        {
            unkillable.Clear();
            for (int x = 0; x < btn.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < btn.GetLength(1); y++)     // Loop for y
                {
                    btn[x, y].BackColor=Color.PowderBlue;
                    btn[x, y].Text = "";
                }
            }

        }

        //adds an arraay of buttons with size dependent on bSz the grid size it determined by the btn array
        public void addButtons(int bPO, int bSz) {
            int gridOffSetX = 30;
            int gridOffSetY = 50;
            int buttonPosOffset = bPO;
            int buttonSize = bSz;
            for (int x = 0; x < btn.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < btn.GetLength(1); y++)     // Loop for y
                {
                    btn[x, y] = new Button();
                    btn[x, y].Font = new Font(btn[x, y].Font.FontFamily, 24);
                    btn[x, y].TextAlign = ContentAlignment.MiddleRight;
                    btn[x, y].Name = Convert.ToString((x + 1) + "," + (y + 1));
                    btn[x, y].SetBounds(gridOffSetX + buttonPosOffset * x + 1, gridOffSetY + buttonPosOffset * y + 1, buttonSize, buttonSize);
                    btn[x, y].BackColor = Color.PowderBlue;
                    //btn[x, y].Text = Convert.ToString((x + 1) + "," + (y + 1));
                    btn[x, y].Click += new EventHandler(this.btnEvent_Click);
                    btn[x, y].MouseEnter += new EventHandler(this.btnEvent_Enter);
                    
                    
                    Controls.Add(btn[x, y]);
                }
            }
        }
        void btnEvent_Click(object sender, EventArgs e)
        {
            Console.WriteLine(((Button)sender).Text);    // SAME handler as before
            if (!clickHeld) {
                clickHeld = true;
                clickColor = ((Button)sender).BackColor;
            }
            else
            {
                clickHeld = false;
            }

            //Color clickColor = ((Button)sender).BackColor;
        }
        void btnEvent_Enter(object sender, EventArgs e)
        {
            if (clickHeld && !unkillable.Contains((Button)sender))
            {
                ((Button)sender).BackColor = clickColor;
            }
        }

        //opens the seperate rules form so the user can see how the game works
        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rules form = new Rules();
            form.Show(this); 
        }
        //adds a start and end point to a 'flow' these are buttons whose colour cant be overriden and are connected to each other while playing
        private void addFlowPath(int startX, int startY, int endX, int endY, Color col) {
            Button start = btn[startX, startY];
            Button end = btn[endX, endY];
            start.Text = "o";
            end.Text = "o";
            unkillable.Add(start);
            unkillable.Add(end);
            start.BackColor = col;
            end.BackColor = col;
        }
        //takes an array of positions and colours and creates a level with them
        private void proccessLevel(int[,] path, Color[] col)
        {
            for (int x = 0; x < path.GetLength(0); x++)
            {
                //Color randomColor = Color.FromArgb(r.Next(256), r.Next(256), r.Next(256));
                addFlowPath(path[x,0], path[x,1], path[x,2], path[x,3], col[x]);
            }
        }
        //converts board to string of colours which can be compared with solutions
        private string convBoardToString()
        {
            string outP = "";
            for (int x = 0; x < btn.GetLength(0); x++)
            {
                for (int y = 0; y < btn.GetLength(1); y++)
                {
                    outP += btn[x, y].BackColor.GetHashCode()+";";
                }
                outP += ":";
            }
            return outP;
        }

        //loads a level in using proccessLevel, 9 are avaliable
        private void loadLevel(int level)
        {
            killColor();
           switch(level){
                case 1:
                    int[,] easy1 = { { 0, 0, 1, 4, }, { 1, 0, 1, 3 }, { 2, 0, 3, 2 }, { 3, 1, 4, 3 }, { 2, 4, 4, 4 } };
                    Color[] easy1C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange };
                    
                    proccessLevel(easy1, easy1C);
                    break;
                case 2:
                    int[,] easy2 = { { 2, 0, 4, 3 }, { 0, 0, 3, 3 }, { 0, 1, 0, 3 }, { 2, 3, 4, 4 }, { 2, 2, 0, 4 } };
                    Color[] easy2C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange };
                    proccessLevel(easy2, easy2C);
                    break;
                case 3:
                    int[,] easy3 = { { 1, 1, 1, 3 }, { 4, 1, 3, 3 }, { 4, 0, 2, 0 }, { 3, 1, 4, 3 }, { 1, 0, 1, 4 } };
                    Color[] easy3C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange };
                    proccessLevel(easy3, easy3C);
                    break;
                case 4:
                    int[,] med1 = { { 1, 0, 3, 5 }, { 1, 3, 4, 4 }, { 2, 1, 4, 1 }, { 1, 1, 4, 5 }, { 5, 0, 3, 1 } };
                    Color[] med1C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange };
                    proccessLevel(med1, med1C);
                    break;
                case 5:
                    int[,] med2 = { { 0, 0, 1, 5 }, { 3, 2, 2, 5 }, { 4, 1, 2, 3 }, { 1, 4, 4, 4 }, { 1, 3, 4, 2 }  };
                    Color[] med2C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange };
                    proccessLevel(med2, med2C);
                    break;
                case 6:
                    int[,] med3 = { { 2, 1, 2, 3 }, { 1, 1, 5, 2 }, { 5, 3, 1, 5 }, { 4, 2, 4, 4 }, { 5, 0, 0, 5 } };
                    Color[] med3C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange };
                    proccessLevel(med3, med3C);
                    break;
                case 7:
                    int[,] hard1 = { { 1, 6, 5, 4 }, { 4, 2, 3, 3 }, { 4, 4, 5, 5 }, { 0, 6, 6, 5 }, { 2, 1, 1, 5 }, { 3, 4, 6, 6 } };
                    Color[] hard1C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange , Color.Pink};
                    proccessLevel(hard1, hard1C);
                    break;
                case 8:
                    int[,] hard2 = { { 0, 1, 1, 5 }, { 0, 0, 6, 3 }, { 1, 1, 0, 6 }, { 2, 1, 6, 5 }, { 3, 1, 5, 5 }, { 4, 1, 6, 4 } };
                    Color[] hard2C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange, Color.Pink };
                    proccessLevel(hard2, hard2C);
                    break;
                case 9:
                    int[,] hard3 = { { 0, 4, 5, 3 }, { 0, 0, 4, 4 }, { 6, 6, 3, 4 }, { 6, 5, 4, 5 }, { 1, 6, 3, 3 }, { 4, 3, 0, 6 } };
                    Color[] hard3C = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Orange, Color.Pink };
                    proccessLevel(hard3, hard3C);
                    break;
                default:
                    break;
            } 
                
            
        }

        

        //allows the user to select the 'easy' 5x5 levels
        private void EasyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            killButtons();
            btn = new Button[5, 5];
            //textBox1.Text = "5x5";
            addButtons(64,63);
            diffOffset = 0;
        }

        //allows the user to select the 'meduim' 6x6 levels
        private void MedRadioButton_CheckedChanged_1(object sender, EventArgs e)
        {
            killButtons();
            btn = new Button[6, 6];
            //textBox1.Text = "6x6";
            addButtons(53,52);
            diffOffset = 3;
        }

        //allows the user to select the 'hard' 7x7 levels
        private void HardRadioButton_CheckedChanged_1(object sender, EventArgs e)
        {
            killButtons();
            btn = new Button[7, 7];
            //textBox1.Text = "7x7";
            addButtons(46,45);
            diffOffset = 6;
        }

        //checks if the user has got the solution right
        private void button2_Click(object sender, EventArgs e)
        {
            if (solutions[currentLevel-1].Equals(convBoardToString()))
            {
                timer1.Stop();
                textBox2.Text = "Victory";
            }
            else
            {
                textBox2.Text = "Try Again";

            }
        }
        
        //loads level 1 from easy med or hard category
        private void LevelButton1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            time = 0;
            timer1.Start();
            
            currentLevel = 1 + diffOffset;
            loadLevel(currentLevel);
            textBox2.Text = "";
        }
        //loads level 1 from easy med or hard category

        private void LevelButton2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            time = 0;
            timer1.Start();
            currentLevel = 2 + diffOffset;
            loadLevel(currentLevel);
            textBox2.Text = "";
        }
        //loads level 1 from easy med or hard category

        private void LevelButton3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            time = 0;
            timer1.Start();
            currentLevel = 3 + diffOffset;
            loadLevel(currentLevel);
            textBox2.Text = "";
        }
        //initialised board
        private void Flo_Load(object sender, EventArgs e)
        {
            btn = new Button[5, 5];
            //textBox1.Text = "5x5";
            addButtons(64, 63);
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        //closes app
        private void dialogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        //adds to the time variable and displays the timer
        private void timer1_Tick(object sender, EventArgs e)
        {
            time += 0.1;
            LblTimeNo.Text = time.ToString("#####.#");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
